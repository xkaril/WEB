from django.contrib import admin
from django.urls import path
from appointments import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),
    path('compra_de_bonos/', views.compra_de_bonos, name='compra_de_bonos'),
    path('horario/', views.horario, name='horario'),
    path('confirmacion/', views.confirmacion, name='confirmacion'),
    path('especialidad/', views.especialidad, name='especialidad'),
    path('identificacion/', views.identificacion, name='identificacion'),
    path('login/', views.login, name='login'),
    path('nuevo_usuario/', views.nuevo_usuario, name='nuevo_usuario'),
    path('pago/', views.pago, name='pago'),
    path('preguntas_frecuentes/', views.preguntas_frecuentes, name='preguntas_frecuentes'),
    path('servicios/', views.servicios, name='servicios'),
]
