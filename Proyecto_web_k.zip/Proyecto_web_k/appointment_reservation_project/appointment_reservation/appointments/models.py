
from django.db import models
from django.contrib.auth.models import User

class Appointment(models.Model):
    patient = models.ForeignKey(User, on_delete=models.CASCADE)
    doctor = models.CharField(max_length=100)
    date = models.DateTimeField()
    reason = models.TextField()

    def __str__(self):
        return f"Appointment with Dr. {self.doctor} on {self.date}"
