# appointment_reservation/views.py

from django.shortcuts import render

def index(request):
    return render(request, 'index.html')

def compra_de_bonos(request):
    return render(request, 'Compra_de_Bonos.html')

def horario(request):
    return render(request, 'Horario.html')

def confirmacion(request):
    return render(request, 'confirmacion.html')

def especialidad(request):
    return render(request, 'especialidad.html')

def identificacion(request):
    return render(request, 'identificacion.html')

def login(request):
    return render(request, 'login.html')

def nuevo_usuario(request):
    return render(request, 'nuevo_usuario.html')

def pago(request):
    return render(request, 'pago.html')

def preguntas_frecuentes(request):
    return render(request, 'preguntas_frecuentes.html')

def servicios(request):
    return render(request, 'servicios.html')
